package Latihan1

class Control(){
    var masukan1: String? = null
    var masukan2: String? = null
    var keluar: String? = null

    fun suitJepang() {
        if (
            (masukan1.equals("batu") && masukan2.equals("gunting")) ||
            (masukan1.equals("gunting") && masukan2.equals("kertas")) ||
            (masukan1.equals("kertas") && masukan2.equals("batu"))


        ) {
            keluar = "Pemain Menang"
            println(keluar)
            Game()

        } else if (
            (masukan2.equals("batu") && masukan1.equals("gunting")) ||
            (masukan2.equals("gunting") && masukan1.equals("kertas")) ||
            (masukan2.equals("kertas") && masukan1.equals("batu"))
        ) {
            keluar = "CPU Menang"
            println(keluar)
            Game()

        } else if (
            (masukan1.equals("batu") && masukan2.equals("batu")) ||
            (masukan1.equals("gunting") && masukan2.equals("gunting")) ||
            (masukan1.equals("kertas") && masukan2.equals("kertas"))
        ) {
            keluar = "Draw"
            println(keluar)
            Game()

        } else {
            keluar = "Hasil Eror"
            (println(keluar))
            Game()
        }
    }
}



class Player(){
    var player1: String? = null
    var CPU: String? = null

    fun playerVsComputer(){
        println("===================================\n"+
                "--- Pemain Vs CPU ---\n"+
                "Masukan Pilihan Anda (kertas, gunting, batu: \n")

        player1 = readLine()!!.toString().toLowerCase()
        val opsi = arrayOf("batu", "kertas", "gunting")
        CPU = opsi.random()
        println("Masukan Computer : $CPU")
    }
}