

//fun namaMethod(){
//}

fun kenalan(){
    println("Kenalan dong")
}

fun main(){

    fun ganjilGenap(){

    }
    val salepku = SalepHotInCream()
    println("Volume Salepku : ${salepku.menghitungVolumeBotol()}")
    salepku.mengeluarkanSalep(5,"Kuning")

    val saldoRekeningSaya = 5000001
    println("Num ganjil apa genap? ${saldoRekeningSaya.isOddOrEven()}")
    // "Rp. 5.000.000,-"

    RoleAccount.ipk

//    val makhlukHidup = MakhlukHidup()
}

fun Int.isOddOrEven():String {
    return if(this % 2 == 0){
        "Genap"
    }else{
        "Ganjil"
    }
}

