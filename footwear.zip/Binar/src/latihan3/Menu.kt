package latihan3



import kotlin.system.exitProcess

class Menu {
//    private var nama : MutableList<String> = ArrayList()
//    private var harga : MutableList<String> = ArrayList()
//    private var tipe : MutableList<String> = ArrayList()
//    private var tinggi : MutableList<String> = ArrayList()
    var account = arrayListOf<database>()


    fun selectMenu() {
        println(
            """
            Just Du It !!
            ===============
            1. Add Footwear
            2. View Footwear
            3. Update Footwear
            4. Delete Footwear
            5. Exit
            =======================================================
            Masukkan Pilihan Anda (1,2,3,4,5) ?
            
        """.trimIndent()
        )
        when (readLine()!!) {

            "1" -> {
                addFootwear()
                selectMenu()

            }
            "2" -> {
                viewFootwear()
            }
            "3" -> {
                updateFootwear()
            }
            "4" -> {
                deleteFootwear()
            }
            "5" -> {
                exitProcess(0)
            }
            else -> {
                println("Pilihan Tidak Ada")
            }
        }
        selectMenu()
    }

    private fun addFootwear() {
        println("=======================================================")

        val nama = validatename()
        val harga = validateprice()
        val tipe = validatetype()



        when(tipe){
            "heels" -> {
                val tinggi = heightheels()
                val value = database(nama, harga, tipe, tinggi, 0)
                account.add(value)
            }
            "rollerskate" -> {
                val roda = wheelsrollerskate()
                val value = database(nama, harga, tipe, 0.0, roda)
                account.add(value)
            }
        }


    }

    private fun validatename(): String {
        println("Footwear name [3 - 25 characters]: ")
        var name = readLine()!!

        return if (name.length in 3..25) {
            println("Berhasil ditambahkan")
            return name
        }
        else{
            println("Masukan nama sesuai ketentuan")
            return validatename()
        }

    }

    private fun validateprice(): Int {
        println("Footwear price [more than 10000]: ")
        var price = readLine()!!.toInt()
        return if (price >= 10000){
            println("Berhasil ditambahkan")
            return price
        }
        else{
            println("Masukan harga sesuai ketentuan")
            return validateprice()
        }
    }
    private fun validatetype(): String {
        println("Footwear type (Heels / RollerSkate): ")
        var type = readLine()!!.toLowerCase()

        return if (type == "heels" || type == "rollerskate"){
            return type
        }else{
            validatetype()
        }

    }

    private fun heightheels(): Double {
        println("Footwear height [1.0 - 9.0]: ")
        var height = readLine()!!.toDouble()

        return if (height in 1.0..9.0) {
            println("Berhasil ditambahkan")
            return height


        } else {
            println("Masukan tinggi sesuai ketentuan")
            heightheels()
        }
    }

    private fun wheelsrollerskate(): Int {
        println("Footwear  wheels [2 - 4]: ")
        var wheels = readLine()!!.toInt()

        return if (wheels in 2..4) {
            println("Berhasil ditambahkan")
            return wheels

        } else {
            println("Masukan roda sesuai ketentuan")
            wheelsrollerskate()
        }
    }

    private fun viewFootwear(){
        println("===========================================================================")
        println("| Name \t\t\t| Price \t\t| Type \t\t\t\t| Height\t\t| Wheels\t\t")
        println("===========================================================================")

        for (i in account){
            println("| ${i.name} \t\t\t| ${i.price} \t\t|" +
                    "${i.type} \t\t| ${i.height} \t\t\t| ${i.wheels} ")

        }
    }

    private fun deleteFootwear(){
        viewFootwear()
        println("Silahkan pilih index yang ingin dihapus : ")
        var id = readLine()!!.toInt()
        account.removeAt(id-1)
        println("Data berhasil dihapus !!! ")
        selectMenu()
    }

    private fun updateFootwear(){
        viewFootwear()
        println("Silahkan pilih index yang ingin anda hapus : ")

        var index = readLine()!!.toInt()
        var nama = validatename()
        var harga = validateprice()
        var tipe = validatetype()

        if (account[index-1].type == "heels"){
            var tinggi = heightheels()
            val value = database(nama, harga, tipe, tinggi, 0)
            account.set(index-1, value)

        }else if(account[index-1].type == "rollerskate"){
            var roda = wheelsrollerskate()
            val value = database(nama, harga, tipe, 0.0, roda)
            account.set(index-1, value)
        }

    }



}