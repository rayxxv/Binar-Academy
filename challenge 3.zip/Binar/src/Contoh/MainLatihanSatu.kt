package latihansatu

fun main(){
    val myGame = GameMachine()
    myGame.showMenu()
}




//GameMachine
//showMenu()
//newGame()
//generateComputerChoice()
//retrieveUserChoice()
//login()
//register()
//determineWinner()
//declareDraw()
//Player -> Account
//declareWin()
//declareLose()
//editUsername()
//changePassword()

//---
//History -> Additional :
//Winner
//loser
//time
