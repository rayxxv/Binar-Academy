package latihan3

data class database(val name: String, val price: Int, val type: String, val height: Double, val wheels: Int) {

}
