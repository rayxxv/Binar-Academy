package latihansatu

class Player(override val username: String, override val password: String): Account(username, password){
    override fun sayWin() {
            println("$username is Winner!")
    }

    override fun sayLose() {
            println("CPU is Winner!")
    }
}
