fun main(){
    println("Hello Binar!")
}