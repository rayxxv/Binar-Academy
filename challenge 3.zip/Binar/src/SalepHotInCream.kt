//Property / Varieble / Field
//Method

class SalepHotInCream {
    //Property -> Kata Benda
    val warna = "Putih-Merah"
    private val tinggiBotol = 7
    protected val jariJariTutup = 4.5

    //method -> kara kerja

    fun membukaTutupBotol(){
        println("Tutup botol terbuka")
    }

    fun setTinggiBotol(tinggiBotol: Int){
//        if(tinggiBotol > 0){
//            this.tinggiBotol = tinggiBotol
//        }
    }

    fun mengeluarkanSalep(jumlahMl: Int, warna: String = "Putih"){
        println("Salep keluar sebanyak $jumlahMl mililiter warnanya $warna")
    }

    fun memencetBotol(){
        println("Botol mengempis")
    }

    fun membuangDiri(){             //Void Function
        println("Botol terbuang")
    }

    fun menghitungVolumeBotol(): Double {
        return 3.14*jariJariTutup*jariJariTutup*tinggiBotol
    }

    //Access Modifier
    //Public        -> Dapat diakses dari mana saja
    //Private       -> Hanya dapat diakses oleh kelasnya sendiri
    //Protected     -> Hanya dapat diakses oleh kelasnya sendiri DAN turunannya
    //Internal
}