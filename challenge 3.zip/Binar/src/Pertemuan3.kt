fun main(){
    //Variable Nullable -> Bisa diisi dengan nilai NULL
    //Variable Non Null -> Gaboleh diisi nilai NULL

    //Ciri suatu variable Nullable -> Ada tandatanya di akhir tipe data
    val username: String = "Senno"

//    val bil = 3
//
//    when {
//        bil == 1 -> {
//            //Condition 1
//            println("Masuk con 1")
//        }
//        bil < 5 -> {
//            //condition 2
//            println("Masuk con 2")
//        }
//        bil > 10 -> {
//            //
//            println("Masuk con 3")
//        }
//        else -> {
//            println("Masuk con 4")
//        }
//    }



    val lampu = "Magenta"

    when(lampu){
        "Merah" -> {
            println("Stop")
        }
        "Hijau" -> {
            println("Jalan")
        }
        "Kuning" -> {
            println("Siap2")
        }
        else -> {
            println("Warna apaan nih??")
        }
    }

    for(i in 1..3){
        println("Bil $i")
    }


//    var bil = 1
//    while(/*Condition*/ bil <= 5){
//        //statement 1
//        println("Hello")
//        bil++
//    }

    //Increment ++
    //Decrement --
    //Pre ++num
    //Post num++

    //+ - * / %
    // 3 mod 10

    var num = 7

//    num -= 7 // num = 14

    println("Nilai Num : $num")


    do{
        println("Statement do while dijalankan")
    }while (num < 3)

    for(i in 1..10){
        if(i == 3) continue
        println("Bilangan : $i")

    }

    // AND --> Dua kondisi semuanya harus true untuk menghasilkan TRUE
    // 1 AND 1 = 1
    // 1 AND 0 = 0
    // 0 AND 1 = 0
    // 0 AND 0 = 0

    // OR --> Salah satu true --> TRUE
    // 1 AND 1 = 1
    // 1 AND 0 = 1
    // 0 AND 1 = 1
    // 0 AND 0 = 0

    // Exclusive Or --> Hanya boleh satu yg true
    // 1 AND 1 = 0
    // 0 and 1 = 1
    // 1 and 0 = 1
    // 0 and 0 = 0

    //val ayam 1 = deklarasi
    //Ayam() = instansiasi
    // = Assignment
    val ayam1 = Ayam("Kukut",1)
    ayam1.berkokok()
}