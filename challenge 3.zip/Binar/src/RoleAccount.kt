object RoleAccount {
    const val ipk = 3.5
    const val nama = "Senno"
}

data class Siswa(val nama: String, val alamat: String)