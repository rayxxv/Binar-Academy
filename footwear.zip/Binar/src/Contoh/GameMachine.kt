package latihansatu

class GameMachine {
    //property ??
    private val listPlayer = arrayListOf<Player>()

    //method
    fun showMenu(){
        println("""
        ==========================
        GAME SUIT TERMINAL VERSION
        ==========================
        1. Registration
        2. Login
        """.trimIndent())

        print("Input Choice : ")

        //  Non Null   = NullAble
        // !! -> Double Exclamation Marks -> Maksain Non Null masuk ke Nullable
        // ? -> Safe Call (Pemanggilan yang Aman) ->
        // "Aku mau ngambil nilai ini, Null nggak?" Kalo nggak nul, gw ambil. Kalo null, skip dulu

        when(readLine()?.toInt()){
            1 -> {
                register()
            }
            2 -> {
                print("Username : ")
                val usernameInput = readLine().toString()
                print("Password : ")
                val passwordInput = readLine().toString()

                login(usernameInput, passwordInput)
            }
            else -> {
                println("Invalid input! Try again.")
                showMenu()
            }
        }
    }

    private fun login(usernameInput: String, passwordInput: String){
        var isLoginSuccess = false
        var signedPlayer = Player("","")

        //For each -> dipretelin satu2
        for(account in listPlayer){
            if(account.username == usernameInput /*true*/ && account.password == passwordInput /*true*/){
                isLoginSuccess = true
                signedPlayer = account
            }
        }

        if(isLoginSuccess){
            playGame(signedPlayer)
        }else{
            println("Wrong Username or Password!")
            showMenu()
        }
    }

    private fun register(){
        print("Input username : ")
        val username = readLine().toString()
        print("Input password : ")
        val password = readLine().toString()

        val player = Player(username, password)
        listPlayer.add(player)

        println("Register berhasil!")
        showMenu()
    }

    private fun generateCpuChoice(): String {
        val cpuChoice = listOf("kertas","batu","gunting").random()
        print("CPU Choice : $cpuChoice\n")
        return cpuChoice
    }

    private fun retrieveUserChoice(player: Player): String {
        print("${player.username} choice : ")
        return readLine().toString().lowercase()
    }

    private fun declareDraw(){
        println("DRAW !")
    }

    private fun playGame(player: Player){
        println("Welcome ${player.username}")
        println("input kertas / batu / gunting")

        //userChoice ATAU cpuChoice pasti isinya kertas / batu / gunting
        val userChoice = retrieveUserChoice(player)
        val cpuChoice = generateCpuChoice()

        when (determineWinner(userChoice, cpuChoice)) {
            "user" -> {
                player.sayWin()
            }
            "cpu" -> {
                player.sayLose()
            }
            "draw" -> {
                declareDraw()
            }
        }
    }

    private fun determineWinner(userChoice: String, cpuChoice: String) : String{
        when{
            //user menang
            ((userChoice == "gunting" && cpuChoice == "kertas") ||
                    (userChoice == "batu" && cpuChoice == "gunting") ||
                    (userChoice == "kertas" && cpuChoice == "batu")) -> {
                return "user"
            }

            (userChoice == cpuChoice) -> {
                return "draw"
            }

            else -> {
                return "cpu"
            }
        }
    }
}