interface Callback {
    fun kirimNilaiBalik(cetakHasil: String)
}