package latihansatu

abstract class Account(open val username: String,open val password: String) {

    abstract fun sayWin()
    abstract fun sayLose()
}