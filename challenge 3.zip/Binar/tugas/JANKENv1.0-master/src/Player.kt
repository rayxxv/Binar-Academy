class Player(){
    var player1: String? = null
    var player2: String? = null
    var compAi: String? = null

    fun plaverVsPlayer(){
        println("===================================")
        println("--- Latihan1.Player Vs Latihan1.Player ---")
        print("Masukan Latihan1.Player 1 : ")
        player1 = readLine()!!.toString()
        print("Masukan Latihan1.Player 2 : ")
        player2 = readLine()!!.toString()
    }
    fun playerVsComputer(){
        println("===================================")
        println("--- Latihan1.Player Vs Computer ---")
        print("Masukan Latihan1.Player 1 : ")
        player1 = readLine()!!.toString()
        val random = listOf("Batu", "Kertas", "Gunting")
        compAi = random.random()
        println("Masukan Computer : $compAi")
    }
}