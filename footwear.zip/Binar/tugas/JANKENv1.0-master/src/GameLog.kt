class GameLog () {
    var listPemenangPVP = mutableListOf<String>()
    var listPemenangPVC = mutableListOf<String>()


    fun addListPVP(player:String){
        this.listPemenangPVP.add(player)
    }

    fun addListPVC(computer:String){
        this.listPemenangPVC.add(computer)
    }
    fun cetakGameLog() {
        println("===================================")
        println("--- Latihan1.Game Log Janken ---")
        println("+++ Latihan1.Player Vs Latihan1.Player +++")
        listPemenangPVP.forEachIndexed { index, s ->
            println("Latihan1.Game ke ${index+1} : $s")
        }
        println("\n+++ Latihan1.Player Vs Computer +++")
        listPemenangPVC.forEachIndexed { index, s ->
            println("Latihan1.Game ke ${index+1} : $s")
        }
    }
}