package Latihan1

import kotlin.system.exitProcess

var inputMenu = 0
val player = Player()
val Play = Control()

fun Game() {
    println("Selamat datang di Permainan kertas, gunting, batu \n" +
            "===================================================\n" +
            "1.Player Vs CPU\n" +
            "2. Keluar\n" +
            "===================================================\n" +
            "Masukan Pilihan : \n" +
            "===================================================\n")
    inputMenu = readLine()!!.toInt()

    if (inputMenu == 1){
        player.playerVsComputer()
        Play.masukan1 = player.player1
        Play.masukan2 = player.CPU
        println("Hasil : ")
        Play.suitJepang()
    }

    else if (inputMenu == 2){
        println("Keluar game")
        exitProcess(0)
    }
    else {
        println("Pilihanmu salah! coba lagi!")
        Game()
    }
}