//Naming Convention

// Function / Method / Prochedure
// Field / Variable / Attribut / Property

//PascalCase -> SetiapKataDiawaliHurufKapital --> Penulisan / Penamaan Class.
//camelCase  --> untuk Variable dan Function    -> method dan attribut
//UPPER_CASE --> Semuanya besar TAPI dipisahkan oleh _ untuk setiap kata --> attribut TAPI yang static dan final PHI = 3.14 KAKI_MANUSIA = 2
//kebab-case --> kecil semua, tapi dipisahin pakai - di setiap katanya --> Resource
//snake_case --> mirip kebab case, tapi dipisah pake _ --> id Resource
      //primary constructor

//Subclass
class Ayam(var name:String, val age: Int) : MakhlukHidup(), IMakhlukHidup {
    lateinit var alamat: String

    init {
        this.name = "Si $name"
        println("Object Ayam dibuat menggunakan primary Constructor")
    }

    constructor(name: String, age: Int, warnaBulu: String) : this(name, age) {
        println("Object Ayam dibuat menggunakan Secondary Constructor")
        println("Nama : $name | age : $age | warna bulu : $warnaBulu")
        alamat = "bandung"
    }


    //method

    //Suatu method yang namanya sama bisa dikatakan berbeda ASALKAN
    //1. beda tipe data
    //2. beda jumlah parameter
    //3. beda urutan parameter

    //No Param
    fun berkokok(){
        println("Si $name berkokok")
    }

    //1 -> String
    fun berkokok(waktu: String){
        println("$name yang berwarna ${warna} berkokok pada $waktu")
    }

    //1 -> Int
    fun berkokok(jumlahKokokan: Int){
        println("Si $name berkokok dengan $jumlahKokokan kali kokokan")
    }

    //2 Int, String
    fun berkokok(waktu: Int, namaTeman: String){
        println("Si kokok berkokok pada $waktu dengan si $namaTeman")
    }

    //2 String, Int
    fun berkokok(namaTeman: String, waktu: Int){
        println("Si kokok berkokok pada $waktu dengan si $namaTeman")
    }

    fun suatuMethod(){
        berkokok( "Rembo", 1900)
    }

    override var jumlahKaki: Int
        get() = 2
        set(value) {}

    override fun caraBergerak() {
        println("Ayam bergerak menggunakan Ceker dan Sayap")
    }

    override fun someMethod() {

    }

    override fun makan() {

    }

    override fun bernafas() {
        super.bernafas()

        println("Ayam bernafas menggunakan paru-paru")
    }

}













/*
* If - Else 💚
* When 💚
* Null Safety 💚
* Debugging 💚
* Loop For / While / Do-While 💚
* Return Break Continue 💚
* Operator Logika, Aritmatika, Inc / Dec 💚
* Class Object 💚
* Constructor 💚
* Name Convention 💚
* Istilah Fiels / Att / Vari / Prop , Mthod 💚
* Kuis
* Instantiation, Declaration, Assignment
*
*
*
* Class 💚
* Abstract Class
* Abstraction
* Object CLass 💚
* Object 💚
* Constructor/Sec / C++ Destructor --> Garbage Collector
* Overloading -> 1 nama function bisa melakukan hal yang berbeda2 💚
*
* Overriding
* Func Extension 💚
* Polymorphism -> (Static-> Overloading 💚 / Dinamic)
* Access Modifier -> Public, Private, Protected 💚
* Inheritance -> Pewarisan ->
* SuperClass
* Subclsss
* Interface
* */


















