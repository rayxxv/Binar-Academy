fun main(){

    //Soal 1 -> bentuk

    //Soal 2 ->

    //2 Tipe variable
    //1 Immutable --> Value / Nilainya tidak dapat diubah -> val
    //2 Mutable --> Value / Nilainya bisa diubah -> var

//    val username = "sennohananto" //Immutable
//
//    var alamat = "Jakarta" //Mutable
//    alamat = "Jawa Tengah"
//

    val umur: Int = 14
    println("Umur : $umur")

    val tinggiBadan:Double = 1.5
    println("Tinggi badan : $tinggiBadan CM")

    //Beda String dan Char -->
    //Char      --> terdiri dari 1 Karakter --> 'A' 'B'
    //String    --> terdiri dari 1 atau lebih char --> "A"
    val nilaiMutu: Char = 'A'
    println("Nilai mutu : $nilaiMutu")

    val nilaiMaxFloat = Float.MAX_VALUE
    println("Nilai Max Float $nilaiMaxFloat")

    val statusLulus:Boolean = true
    println("Status Lulu : $statusLulus")

    val stringEscaped = "Nama : Senno \nAlamat \\t\t BSD"
    println("Val : $stringEscaped")

//    val deretBilangan = intArrayOf(1,3,5,7,9)
//    println(deretBilangan)
    //Size = 5
    //Max Index = 4

//    val deretBilangan = intArrayOf()
//    println("Indeks Ke-2  : ${deretBilangan[2]}")

    val listName = arrayListOf("Arif","Farhan")
    listName.add("Rafly")
    println("Size listname ${listName.size}")

    println("1. ${listName[0]}")

    val num = readLine()
    println("Num : $num")



    //BilBul
//    Byte
//    Short
//    Integer
//    Long

    //Pecahan
//    Float
//    Double


}