fun main(){

}

//Abstract Class
// 1. Class Abstract GAK BISA DIINSTANSIASI / Dibikin Objectnya.
// 2. Bisa menampung Abstract Method
abstract class MakhlukHidup() {
    abstract var jumlahKaki: Int
    //Property : Warna, Alat Bernafas

    //Block code yang dijalankan ketika suatu object dibuat
    init {
        println("init block di class Abstract Makhluk hidup dijalankan")
    }

    abstract fun caraBergerak()

    var warna: String = "Merah"
    protected lateinit var alatBernafas: String

    constructor(warna: String, alatBernafas: String):this(){
        this.warna = warna
    }

    protected fun sebutWarna(){
        println("Warnanya $warna")
    }

    fun sebutAlatBernafas(){
        println("Alat Bernafas : $alatBernafas")
    }

    open fun bernafas(){
        println("Makhluk hidup bernafas")
    }
}