package Latihan1

var user : MutableList<String> = ArrayList()
var pass : MutableList<String> = ArrayList()

fun main(){
    println("Selamat datang Silahkan login\n" +
            "===========silahkan masuk ke permainan===========\n" +
            "===================================================\n" +
            "1.Registration\n" +
            "2. Login\n" +
            "===================================================\n")

    var pilihan = readLine()!!.toInt()

    if (pilihan == 1){
        Registration()
    }

    else if (pilihan == 2){
        Login()
    }

    else{
        println("Masukan pilihan yang benar !!!")
    }
}