package Latihan1


class daftar{
    init {
        println("==============Silahkan Tambahkan Username dan Password anda==============")
        println("Latihan1.Registration\n")

        println(" Input Username : ")
    }
    var username : String = readLine()!!

    init {
        println("Password : ")
    }
    var password : String = readLine()!!

    init {
        println("Confirm Password : ")
    }
    var confirmPass : String = readLine()!!

}


fun Registration(){
    val regist = daftar()

    if (regist.username.isNotEmpty() && regist.password.isNotEmpty() && regist.confirmPass.isNotEmpty()){
        if (regist.password != regist.confirmPass) {
            println("Password berbeda, input Password anda kembali")

            while (false) {
                print("Input Password : ")
                var password = readLine()!!
                print("Confirm Password : ")
                var confirmPass = readLine()!!

                if (regist.password.isNotEmpty() && regist.confirmPass.isNotEmpty()) {
                    if (regist.password != regist.confirmPass) {
                        println("Password berbeda, input Password anda kembali")
                        Registration()
                    }
                    else {
                        println("Berhasil Tambah Akun!\n")
                        user.add(regist.username)
                        pass.add(regist.password)
                        Login()

                    }
                    
                } else {
                    println("Silahkan Mengulang Kembali !")
                }
            }
            Registration()
        }
        else{
            println("Berhasil Tambah Akun!\n")
            user.add(regist.username)
            pass.add(regist.password)
            Login()
        }
    }else{
        println("Username atau password anda kosong, Silahkan Mengulang Kembali !")
        Registration()
    }
}



