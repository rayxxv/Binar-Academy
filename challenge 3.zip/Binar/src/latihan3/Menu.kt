package latihan3



import latihansatu.Player
import kotlin.system.exitProcess

class Menu {
//    private var nama : MutableList<String> = ArrayList()
//    private var harga : MutableList<String> = ArrayList()
//    private var tipe : MutableList<String> = ArrayList()
//    private var tinggi : MutableList<String> = ArrayList()
    var account = arrayListOf<database>()


    fun selectMenu() {
        println(
            """
            Just Du It !!
            ===============
            1. Add Footwear
            2. View Footwear
            3. Update Footwear
            4. Delete Footwear
            5. Exit
            =======================================================
            Masukkan Pilihan Anda (1,2,3,4,5) ?
            
        """.trimIndent()
        )
        when (readLine()!!) {

            "1" -> {
                addFootwear()

            }
//            "2" -> {
//                viewFootwear(dao.getStudents())
//            }
//            "3" -> {
//                updateFootwear()
//            }
//            "4" -> {
//                deleteFootwear()
//            }
            "5" -> {
                exitProcess(0)
            }
            else -> {
                println("Pilihan Tidak Ada")
            }
        }
        selectMenu()
    }

    private fun addFootwear() {
        println("=======================================================")
        validatename()
        validateprice()
        validatetype()
        var nama = validatename()
        var harga = validateprice()
        var tipe = validatetype()
        var tinggi = heightheels()
        var roda = wheelsrollerskate()

        var value = database(nama, harga, tipe, tinggi, roda)
        account.add()
    }

    private fun validatename(): String {
        println("Footwear name [3 - 25 characters]: ")
        var name = readLine()!!

        return if (name.length in 3..25) {
            println("Berhasil ditambahkan")
            return name
        }
        else{
            println("Masukan nama sesuai ketentuan")
            return validatename()
        }

    }

    private fun validateprice(): Int {
        println("Footwear price [more than 10000]: ")
        var price = readLine()!!.toInt()
        return if (price >= 10000){
            println("Berhasil ditambahkan")
            return price
        }
        else{
            println("Masukan harga sesuai ketentuan")
            return validateprice()
        }
    }
    private fun validatetype(){
        println("Footwear type (Heels / RollerSkate): ")
        var type = readLine()!!.toLowerCase()

        if ("heels" in type){
            heightheels()

        }
        else if ("rollerskate" in type){
            wheelsrollerskate()

        }else{
            validatetype()
        }

    }

    private fun heightheels(): Double {
        println("Footwear height [1.0 - 9.0]: ")
        var height = readLine()!!.toDouble()

        if (height in 1.0..9.0){
            println("Berhasil ditambahkan")
            return height

        }
        else{
            println("Masukan tinggi sesuai ketentuan")
            return heightheels()
        }
    }

    private fun wheelsrollerskate(): Int {
        println("Footwear  wheels [2 - 4]: ")
        var wheels = readLine()!!.toInt()

        if ( wheels in 2..4){
            println("Berhasil ditambahkan")
            return wheels

        }
        else{
            println("Masukan roda sesuai ketentuan")
            return wheelsrollerskate()
        }
    }

}