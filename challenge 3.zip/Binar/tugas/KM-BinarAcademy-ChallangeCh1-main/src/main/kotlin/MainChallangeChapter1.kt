fun main() {
    val nomer1 = SegitigaSamaKaki()
    nomer1.soal1(8)

    val nomer2 = SegitigaSamaKakiTerbalik()
    nomer2.soal2(8)

    val nomer3 = BelahKetupat()
    nomer3.soal3(8)

    val nomer4 = PolaX()
    nomer4.soal4(7)

    val nomer5 = SegitigaSikuSiku()
    nomer5.soal5(8)
}

