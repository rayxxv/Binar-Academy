package Latihan1

import Latihan1.Game
import Latihan1.pass
import Latihan1.user

class Masuk {
    init {
        println("==============Silahkan Masukan Username dan Password anda==============")
        println("Login Page\n")

        println(" Input Username : ")
    }
    var username : String = readLine()!!

    init {
        println("Password : ")
    }
    var password : String = readLine()!!
}

fun Login(){
    val signin = Masuk()
    if (signin.username.isNotEmpty() && signin.password.isNotEmpty()){
        for ((index, user) in user.withIndex()){
            if (signin.username == user && signin.password == pass[index]){
                println("berhasil")
                Game()
            }
            else{
                println("Username atau Password berbeda, Silahkan input kembali")
                Masuk()
            }
        }
    }
    else {
        println("Username atau Password berbeda, Silahkan input kembali")
        Masuk()
    }


}