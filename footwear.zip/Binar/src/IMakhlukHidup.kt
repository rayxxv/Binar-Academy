interface IMakhlukHidup {
    //Membernya Abstract Semua
    fun someMethod()
    fun makan()
    fun bernafas()
}