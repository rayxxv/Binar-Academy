fun main(){
    val remboSecondary = Ayam("Rembo",2,"Merah")

    val remboPrimary = Ayam("Kukut",3)
    remboPrimary.berkokok("Pagi")
    remboPrimary.bernafas()

}