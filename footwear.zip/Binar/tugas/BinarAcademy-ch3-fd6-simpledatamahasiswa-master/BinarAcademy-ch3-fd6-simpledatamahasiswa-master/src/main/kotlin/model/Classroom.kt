package model

data class Classroom(val className: String?, val major: String?)
