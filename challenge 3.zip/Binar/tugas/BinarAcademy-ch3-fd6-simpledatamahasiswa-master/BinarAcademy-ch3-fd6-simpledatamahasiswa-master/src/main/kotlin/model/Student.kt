package model

data class Student(val name: String?, val studentId: String?, val classroom: Classroom)
