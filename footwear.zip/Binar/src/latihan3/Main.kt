package latihan3

fun main(){
    val menu = Menu()
    menu.selectMenu()
}